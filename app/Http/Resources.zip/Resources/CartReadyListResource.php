<?php

namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;

class CartReadyListResource extends JsonResource
{
    public function toArray($request)
    {
        $carts = isset($this->resource['carts']) ? $this->resource['carts'] : [];
        $total_qty = isset($this->resource['total_qty']) ? $this->resource['total_qty'] : 0;

        $admin_settings = getAdminSettings();
        $sales_wastage = (isset($admin_settings['sales_wastage']) && !empty($admin_settings['sales_wastage'])) ? unserialize($admin_settings['sales_wastage']) : [];

        $sales_wastage_discount = (isset($admin_settings['sales_wastage_discount']) && !empty($admin_settings['sales_wastage_discount'])) ? unserialize($admin_settings['sales_wastage_discount']) : [];

        $main_array = [];
        $cart_array = [];

        foreach($carts as $cart){

            // $sales_wastage_of_category = isset($sales_wastage[$category_id]) ? $sales_wastage[$category_id] : 0;

            $data['id'] = (isset($cart->id)) ? $cart->id : '';
            $data['design_id'] = (isset($cart->design_id)) ? $cart->design_id : '';
            $data['user_id'] = (isset($cart->user_id)) ? $cart->user_id : '';
            $data['quantity'] = (isset($cart->quantity)) ? intval($cart->quantity) : '';
            $data['tag_no'] = (isset($cart->tag_no)) ? $cart->tag_no : '';
            $data['group_name'] = (isset($cart->group_name)) ? $cart->group_name : '';
            $data['name'] =  (isset($cart->name)) ? $cart->name : '';
            $data['price'] = isset($cart->price) ? $cart->price : '';
            $data['size'] = isset($cart->size) ? $cart->size : '';
            $data['gross_weight'] = isset($cart->gross_weight) ? $cart->gross_weight : '';
            $data['net_weight'] = isset($cart->net_weight) ? $cart->net_weight : '';
            $data['gold_price'] = isset($cart->gold_price) ? $cart->gold_price : '';
            $data['barcode'] = isset($cart->barcode) ? $cart->barcode : '';
            $data['gold_id'] = isset($cart->gold_id) ? $cart->gold_id : '';

            $data['percentage'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $data['metal_value'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $data['sales_westage'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $data['sales_westage_discount'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $data['making_charge'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $data['making_charge_discount'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $data['total_amount'] = isset($cart->gold_id) ? $cart->gold_id : '';
            $cart_array[] = $data;

        }

        $main_array['carts'] = $cart_array;
        $main_array['total_qty'] = $total_qty;
        return $main_array;
    }
}

